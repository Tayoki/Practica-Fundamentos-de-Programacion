
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define MAX_DATA 10000

typedef struct {
    double x, y;
    int c;
} Point;

double distance(Point a, Point b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

typedef struct {
    double dist;
    int clase;
} Neighbor;

int cmp(const void *a, const void *b) {
    Neighbor *n1 = (Neighbor *)a;
    Neighbor *n2 = (Neighbor *)b;
    if (n1->dist < n2->dist) return -1;
    if (n1->dist > n2->dist) return 1;
    return 0;
}

int classify(Point *train, int n_train, Point test_point, int K) {
    Neighbor *neighbors = malloc(n_train * sizeof(Neighbor));
    if (!neighbors) {
        printf("Error al asignar memoria.\n");
        exit(1);
    }

    for (int i = 0; i < n_train; i++) {
        neighbors[i].dist = distance(train[i], test_point);
        neighbors[i].clase = train[i].c;
    }

    qsort(neighbors, n_train, sizeof(Neighbor), cmp);

    int count0 = 0, count1 = 0;
    for (int i = 0; i < K; i++) {
        if (neighbors[i].clase == 0) count0++;
        else count1++;
    }

    free(neighbors);
    return (count1 > count0) ? 1 : 0;
}

int read_data(const char *filename, Point *data) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Error al abrir el archivo: %s\n", filename);
        exit(1);
    }

    int count = 0;
    char line[256];

    while (fgets(line, sizeof(line), f)) {
        if (strlen(line) < 3 || line[0] == '#')
            continue;

        double x, y;
        int c;

        if (sscanf(line, "%lf %lf %d", &x, &y, &c) == 3) {
            data[count].x = x;
            data[count].y = y;
            data[count].c = c;
            count++;
            if (count >= MAX_DATA) break;
        }
    }

    fclose(f);
    return count;
}

int main() {
    Point train[MAX_DATA];
    Point test[MAX_DATA];

    int n_train = read_data("datos_clases.txt", train);
    int n_test = read_data("puntos_ambiguos_prueba.txt", test);

    printf("Datos de entrenamiento cargados: %d\n", n_train);
    printf("Datos de prueba cargados: %d\n", n_test);

    
    int K = n_test;
    printf("K se ha definido como el numero de puntos de prueba: %d\n", K);

    int correct = 0;
    for (int i = 0; i < n_test; i++) {
        int pred = classify(train, n_train, test[i], K);
        if (pred == test[i].c)
            correct++;
    }

    double accuracy = (double)correct / n_test * 100.0;
    printf("\n=====================================\n");
    printf("   RESULTADOS DEL KNN (K=%d)\n", K);
    printf("   Accuracy: %.2f%%  (%d/%d correctas)\n", accuracy, correct, n_test);
    printf("=====================================\n");

    return 0;
}


